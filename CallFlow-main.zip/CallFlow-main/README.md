# CallFlow
Gerenciador de Chamadas Telefônicas.

Oque é preciso : WsL, biblioteca ncurses

Wsl : wsl --install 

ncurses: sudo apt install libncurses-dev

Primeiro instale Wsl no terminal, normalmente, logo após...

Sicronize com o seu editor de codigo, Se for pelo vscode, o mesmo era lhe apresentar
uma extensão, chamada wsl da propria microsoft. No cmd de ubuntu, coloque.

ncurses: sudo apt install libncurses-dev

Agora, vincule com Vscode do ubuntu.

1. Instale a Extensão "WSL" no VS Code:

Abra o VS Code.
Vá para a aba "Extensions" (Ctrl+Shift+X).
Pesquise por "WSL".
Instale a extensão "WSL" da Microsoft.

2. Abra uma Pasta do WSL no VS Code:

Existem algumas maneiras de fazer isso:
A partir do terminal WSL:
Abra o terminal WSL.
Navegue até a pasta que você deseja abrir no VS Code.
Digite code . (o ponto é importante) e pressione Enter. Isso abrirá o VS Code diretamente na pasta do WSL.
A partir do VS Code:
Abra o VS Code.
Clique no ícone "Remote Explorer" (no canto inferior esquerdo, um ícone com um sinal de "><" ).
Você verá suas distribuições WSL listadas.
Clique no ícone de pasta ao lado da distribuição que você deseja usar.
Navegue até a pasta desejada e clique em "OK".